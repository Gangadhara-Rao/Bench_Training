package Methodoverriding;

public class Animal {

		  public void animalSound() {
		    System.out.println("The animal makes a sound");
		  }
		
}
