package Object;

public class Object {
	public void hello() {
		System.out.println("Hello world");
	}
    public void play() {
    	System.out.println("play cricket");
    }
	public static void main(String[] args) {
		Object obj= new Object();//creating object
		obj.hello();//calling object
		obj.play();
		

	}

}
